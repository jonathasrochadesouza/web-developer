module.exports = {
    dialect: 'postgres',
    host: 'localhost',
    username: 'postgres',
    password: '135790',
    database: 'postgres',
    define : {
        timestamps: true,
        underscore: true,
    },
};