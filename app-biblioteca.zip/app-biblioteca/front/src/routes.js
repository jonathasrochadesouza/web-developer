import React from 'react';
import {BrowserRouter, Route, Switch} from 'react-router-dom';
import HelloMessage from './HelloMessage';
import Teste from './paginas/Teste';

function Routes() {
    return (
        <BrowserRouter>
            <Switch>
                <Route path = "/" exact = {true} component = {HelloMessage}/>,
                <Route path = "/teste" exact = {true} component = {Teste}/>
            </Switch>
        </BrowserRouter>
    );
}

export default Routes;





